# NYC Ride-Hailing Big Data — Đồ án Môn Big Data 2025

> Hệ thống Phân tích và Dự báo Nhu cầu Gọi xe Đô thị New York City  
> Stack: HDFS · PySpark · Kafka · Airflow · MLflow · Streamlit

---

## 🗂️ Cấu trúc dự án

```
nyc_ridehailing_bigdata/
├── docker-compose.yml       # Toàn bộ stack Big Data
├── requirements.txt         # Python dependencies
├── scripts/
│   ├── 01_setup_hdfs.py     # Bước 1: Tạo cấu trúc HDFS
│   └── 02_download_upload.py # Bước 2: Tải & upload NYC TLC 2025
├── spark/
│   ├── 03_read_spark.py     # Bước 3: PySpark đọc dữ liệu
│   ├── 04_etl_clean.py      # Bước 4: ETL + Feature Engineering
│   └── 05_spark_sql.py      # Bước 5: 5 SQL queries phân tích
├── ml/
│   ├── 06_prophet_model.py  # Bước 6a: Prophet baseline
│   └── 06_xgboost_model.py  # Bước 6b: XGBoost main model
├── streaming/
│   └── 08_kafka_producer.py # Bước 8: Kafka streaming simulation
├── airflow/dags/
│   └── nyc_pipeline.py      # Bước 9: Airflow DAG orchestration
└── dashboard/
    └── app.py               # Streamlit dashboard
```

---

## ⚡ Khởi động nhanh

### 1. Cài đặt môi trường

```bash
# Cài Python dependencies
python -m venv venv
venv\Scripts\activate      # Windows
pip install -r requirements.txt
```

### 2. Khởi động Docker stack

```bash
# Khởi động HDFS + Spark + MLflow (nhẹ, chạy trước)
docker-compose up -d namenode datanode spark-master spark-worker mlflow

# Sau 1–2 phút, kiểm tra:
docker ps   # Phải thấy 5 container RUNNING
```

### 3. Chạy pipeline theo thứ tự

```bash
# Bước 1 — Setup HDFS
python scripts/01_setup_hdfs.py

# Bước 2 — Download dữ liệu (mặc định Jan–Mar 2025)
python scripts/02_download_upload.py

# Bước 3 — Đọc & validate
docker exec spark-master spark-submit /opt/bitnami/spark/jobs/03_read_spark.py

# Bước 4 — ETL
docker exec spark-master spark-submit /opt/bitnami/spark/jobs/04_etl_clean.py

# Bước 5 — SQL Analysis
docker exec spark-master spark-submit /opt/bitnami/spark/jobs/05_spark_sql.py

# Bước 6 — Train models
python ml/06_prophet_model.py
python ml/06_xgboost_model.py

# Bước 8 — Kafka streaming
python streaming/08_kafka_producer.py

# Dashboard
streamlit run dashboard/app.py
```

---

## 🌐 Web UIs

| Service | URL | Credentials |
|---|---|---|
| HDFS NameNode | http://localhost:9870 | — |
| Spark Master | http://localhost:8080 | — |
| MLflow | http://localhost:5000 | — |
| Airflow | http://localhost:8081 | admin / admin |
| Streamlit | http://localhost:8501 | — |

---

## 📊 Dữ liệu

| Dataset | Source | Format |
|---|---|---|
| NYC TLC Yellow Taxi 2025 | data.cityofnewyork.us | Parquet |
| Zone Lookup | TLC | CSV |
| NOAA Weather (optional) | ncdc.noaa.gov | CSV |

---

## 👥 Nhóm thực hiện

- **Thành viên 1:** ...
- **Thành viên 2:** ...

---

## 📝 Yêu cầu hệ thống

- RAM: ≥ 12 GB (đã test trên 15.4 GB)
- CPU: ≥ 4 cores
- Disk: ≥ 20 GB trống
- OS: Windows 10/11 + Docker Desktop
