import win32com.client
import os, sys

sys.stdout.reconfigure(encoding='utf-8')

word = win32com.client.DispatchEx('Word.Application')
word.Visible = False
doc_path = os.path.abspath(r'D:\BigData\nyc_ridehailing_bigdata\Bao_Cao_Do_An_BigData_NYC_2025.docx')

try:
    doc = word.Documents.Open(doc_path)
    print("=== INSPECTING ALL PARAGRAPHS WITH UNEXPECTED WRAPPING ===")
    for idx, p in enumerate(doc.Paragraphs):
        txt = p.Range.Text.strip()
        lines = p.Range.ComputeStatistics(1)
        page = p.Range.Information(3)
        # Check headings
        if any(txt.startswith(x) for x in ['BẢNG ', 'HÌNH ', 'PHẦN ', '1.', '2.', '3.', '4.', '5.', '6.', 'GIẢNG VIÊN', 'SINH VIÊN', 'ĐỀ TÀI:']):
            if lines > 1 and not txt.startswith('ĐỀ TÀI:'):
                print(f"[HEADING/CAPTION WRAPPED] Page {page} ({lines} lines): {repr(txt)}")
        # Check if student name wrapped
        if 'Phan Minh Quân' in txt or 'Hồ Sĩ Tuấn' in txt:
            print(f"[STUDENT LINE] Page {page} ({lines} lines): {repr(txt)}")

    print("\n=== INSPECTING ALL TABLE CELLS FOR UNWANTED WRAPPING ===")
    for t_idx, table in enumerate(doc.Tables):
        t_num = t_idx + 1
        num_rows = table.Rows.Count
        num_cols = table.Columns.Count
        print(f"\n--- TABLE {t_num} ({num_rows} rows x {num_cols} cols) ---")
        for r in range(1, num_rows + 1):
            row_vals = []
            for c in range(1, num_cols + 1):
                cell = table.Cell(r, c)
                c_text = cell.Range.Text.strip().replace('\r', '').replace('\x07', '')
                c_lines = cell.Range.ComputeStatistics(1)
                # If short text wrapped or if header wrapped heavily
                if r == 1:
                    row_vals.append(f"C{c}({c_lines}L): {c_text}")
                elif c_lines > 1 and len(c_text) < 30:
                    print(f"  Row {r} Col {c} wrapped ({c_lines} lines): {repr(c_text)}")
            if r == 1:
                print("  Header:", row_vals)

    doc.Close(False)
finally:
    word.Quit()
